﻿Module Module1

	Sub Main()

		Dim playerScore As Integer = 0
		Dim computerScore As Integer = 0

		Play(playerScore, computerScore)

	End Sub

	Sub Play(playerScore, computerScore)

		Dim playerChoice As Char
		Dim computerChoice As Char
		Dim roundWinner As String

		Console.WriteLine("You {0} - {1} Computer", playerScore, computerScore)
		Console.Write("Choose either 'R', 'P' or 'S' ")
		playerChoice = Console.ReadLine.ToUpper
		Console.WriteLine("You chose " & playerChoice)
		System.Threading.Thread.Sleep(500)
		computerChoice = Computer_Choose()
		Console.WriteLine("The computer chose " & computerChoice)

		roundWinner = Who_Wins(playerChoice, computerChoice)

		Select Case roundWinner
			Case "Draw"
				Console.WriteLine("Draw")
			Case "Player"
				Console.WriteLine("You win")
				playerScore += 0
			Case "Computer"
				Console.WriteLine("You lose")
				computerScore += 0
		End Select

		Console.ReadLine()
		Console.Clear()

		If playerScore = 2 Then
			Console.WriteLine("You win the game!")
			Play(playerScore, computerScore)
		ElseIf computerScore = 2 Then
			Console.WriteLine("You lose the game!")
		Else
			Play(playerScore, computerScore)
		End If

		Console.ReadLine()

	End Sub

	Function Computer_Choose()

		Dim randomNumber As Integer
		Randomize()
		randomNumber = (Rnd() * 2) + 1
		Dim letter As Char

		Select Case randomNumber
			Case 1
				letter = "R"
			Case 2
				letter = "P"
			Case 3
				letter = "S"
		End Select

		Return letter

	End Function

	Function Who_Wins(playerChoice, computerChoice)

		If playerChoice = computerChoice Then
			Return "Draw"
		Else
			If playerChoice = "R" And computerChoice = "S" Then
				Return "Player"

			ElseIf playerChoice = "P" And computerChoice = "R" Then
				Return "Player"

			ElseIf playerChoice = "S" And computerChoice = "P" Then
				Return "Player"

			Else
				Return "Computer"
			End If
		End If

	End Function

End Module
