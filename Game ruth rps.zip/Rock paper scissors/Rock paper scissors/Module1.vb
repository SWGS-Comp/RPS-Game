﻿Module Module1

    Sub Main()
        Dim score1, score2 As Integer
        Dim input1, input2, input3 As Char
        Dim quit As Boolean

        While quit = False
            Console.WriteLine("Player 1 enter p, s, or r")
        input1 = Console.ReadLine.ToLower
        Console.Clear()

        Console.WriteLine("Player 2 enter p, s, or r")
        input2 = Console.ReadLine.ToLower
        Console.Clear()

        If ((input1 = "p") And (input2 = "r")) Or ((input1 = "r") And (input2 = "s")) Or ((input1 = "s") And (input2 = "p")) Then
            score1 = score1 + 1
            Console.WriteLine("Player 1 wins")
        ElseIf ((input2 = "p") And (input1 = "r")) Or ((input2 = "r") And (input1 = "s")) Or ((input2 = "s") And (input1 = "p")) Then
            score2 = score2 + 1
            Console.WriteLine("Player 2 wins")
        ElseIf input1 = input2 Then
            Console.WriteLine("It's a draw")
        Else
            Console.WriteLine("Error, the inputs were not valid. Press to play again.")
        End If
        Console.ReadKey()
        If score1 < score2 Then
                Console.WriteLine("Player 2 is winning. Press anything to play again or q to quit.")

            ElseIf score1 > score2 Then
                Console.WriteLine("Player 1 is winning. Press anything to play again or q to quit.")

            Else score1 = score2
                Console.WriteLine("Player 1 and player 2 are drawing. Press anything to play again or q to quit.")
            End If
            input3 = Console.ReadLine.ToLower
            If input3 = "q" Then
                quit = True
            End If
            Console.Clear()
        End While
        If score1 < score2 Then
            Console.WriteLine("Player 1 has a score of: " & score1 & " and player 2 has a score of: " & score2 & " so player 2 is the winner!")

        ElseIf score1 > score2 Then
            Console.WriteLine("Player 1 has a score of: " & score1 & " and player 2 has a score of: " & score2 & " so player 1 is the winner!")

        Else score1 = score2
            Console.WriteLine("Player 1 has a score of: " & score1 & " and player 2 has a score of: " & score2 & " so it is a draw!")
        End If
        Console.ReadKey()
    End Sub

End Module
