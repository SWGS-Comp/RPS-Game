﻿Module Module1
    Dim RandomN, UserWin, BotWin As Integer
    Dim UserInput, PlayAgain As String

    Sub Main()
        Do
            Do Until UserWin = 2 Or BotWin = 2 '               First to win 2 rounds wins
                Console.WriteLine("What would you like to use? (R, P or S)")
                UserInput = Console.ReadLine.ToUpper
                Randomize()
                RandomN = Int(Rnd() * 3) + 1 '                   Getting a random number between 1 and 3
                If RandomN = 1 And UserInput = "R" Then
                    Console.WriteLine("Draw. You both picked rock.")
                    Console.ReadLine()
                ElseIf RandomN = 2 And UserInput = "R" Then
                    BotWin = BotWin + 1
                    Console.WriteLine("Bot wins! It picked paper.")
                    Console.WriteLine("Its score is now " & BotWin & " wins.")
                    Console.ReadLine()
                ElseIf RandomN = 3 And UserInput = "R" Then
                    UserWin = UserWin + 1
                    Console.WriteLine("You win! The bot picked scissors.")
                    Console.WriteLine("Your score is now " & UserWin & " wins.")
                    Console.ReadLine()
                ElseIf RandomN = 1 And UserInput = "P" Then
                    UserWin = UserWin + 1
                    Console.WriteLine("You win! The bot picked rock.")
                    Console.WriteLine("Your score is now " & UserWin & " wins.")
                    Console.ReadLine()
                ElseIf RandomN = 2 And UserInput = "P" Then
                    Console.WriteLine("Draw. You both picked paper.")
                    Console.ReadLine()
                ElseIf RandomN = 3 And UserInput = "P" Then
                    BotWin = BotWin + 1
                    Console.WriteLine("Bot wins! It picked scissors.")
                    Console.WriteLine("Its score is now " & BotWin & " wins.")
                    Console.ReadLine()
                ElseIf RandomN = 1 And UserInput = "S" Then
                    BotWin = BotWin + 1
                    Console.WriteLine("Bot wins! It picked rock.")
                    Console.WriteLine("Its score is now " & BotWin & " wins.")
                    Console.ReadLine()
                ElseIf RandomN = 2 And UserInput = "S" Then
                    UserWin = UserWin + 1
                    Console.WriteLine("You win! The bot picked paper.")
                    Console.WriteLine("Your score is now " & UserWin & " wins.")
                    Console.ReadLine()
                ElseIf RandomN = 3 And UserInput = "S" Then
                    Console.WriteLine("Draw. You both picked scissors.")
                    Console.ReadLine()
                End If
            Loop
            If UserWin = 2 Then
                Console.WriteLine("You win the match, " & UserWin & "-" & BotWin & ".")
                Console.ReadLine()
            ElseIf BotWin = 2 Then
                Console.WriteLine("The bot wins the match, " & BotWin & "-" & UserWin & ".")
                Console.ReadLine()
            End If
            Console.WriteLine("Would you like to play again? (Y/N)")
            PlayAgain = Console.ReadLine.ToUpper
            If PlayAgain = "Y" Then
                BotWin = 0
                UserWin = 0
                Console.WriteLine("You chose to play again.")
                Console.ReadLine()
                Console.Clear()
            Else
                Console.WriteLine("You chose to quit.")
                Console.ReadLine()
                End
            End If
        Loop
    End Sub

End Module
