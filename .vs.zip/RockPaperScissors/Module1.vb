﻿Module Module1
    Dim PlayerScore, CpuScore, Draws As Integer
    Sub Main()
        Console.Clear()

        Console.WriteLine("     ~~Your score:Draws:Computer's score~~")
        Console.WriteLine("               " & PlayerScore & " :  " & Draws & "  : " & CpuScore)
        Console.WriteLine()
        Console.WriteLine("Would you like to play Rock (R), Paper (P), Scissors (S), Lizard (L) or Spock (K)?")
        Selection()
    End Sub
    Sub Selection()
        Dim CC, PC As Char

        PC = PlayerChoose()
        Console.WriteLine()
        Threading.Thread.Sleep(400)
        Console.WriteLine(".")
        Threading.Thread.Sleep(400)
        Console.WriteLine(".")
        Threading.Thread.Sleep(400)
        Console.WriteLine(".")
        Threading.Thread.Sleep(400)
        Console.WriteLine("[Computer is making a selection]")
        Threading.Thread.Sleep(400)
        Console.WriteLine(".")
        Threading.Thread.Sleep(400)
        Console.WriteLine(".")
        Threading.Thread.Sleep(400)
        Console.WriteLine(".")
        Threading.Thread.Sleep(400)
        Console.WriteLine()
        CC = CpuChoose()
        Checkwin(CC, PC)
    End Sub
    Sub Checkwin(CC, PC)

        If CC = PC Then
            Console.WriteLine("It's a draw!")
            Draws = Draws + 1
        ElseIf CC = "R" And PC = "S" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "R" And PC = "L" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "P" And PC = "R" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "P" And PC = "K" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "S" And PC = "P" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "S" And PC = "L" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "L" And PC = "P" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "L" And PC = "K" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "K" And PC = "R" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        ElseIf CC = "K" And PC = "S" Then
            CpuScore = CpuScore + 1
            Console.WriteLine("Computer wins!")
        Else
            PlayerScore = PlayerScore + 1
            Console.WriteLine("Player wins!")
        End If
        Console.ReadLine()
        Main()
    End Sub

    Function CpuChoice()
        Static generator As System.Random = New System.Random
        Return generator.Next(1, 5)
    End Function
    Function PlayerChoose()
        Dim choice As Char = Console.ReadLine.ToUpper

        Select Case choice
            Case "R"
                Console.WriteLine("You've chosen to play Rock")
            Case "P"
                Console.WriteLine("You've chosen to play Paper")
            Case "S"
                Console.WriteLine("You've chosen to play Scissors")
            Case "L"
                Console.WriteLine("You've chosen to play Lizard")
            Case "K"
                Console.WriteLine("You've chosen to play Spock")
            Case Else
                Main()
        End Select
        Return (choice)
    End Function
    Function CpuChoose()
        Dim choice As Integer = CpuChoice()
        Dim Chosen As Char
        Select Case choice
            Case 1
                Console.WriteLine("The computer has chosen to play Rock")
                Chosen = "R"
            Case 2
                Console.WriteLine("The computer has chosen to play Paper")
                Chosen = "P"
            Case 3
                Console.WriteLine("The computer has chosen to play Scissors")
                Chosen = "S"
            Case 4
                Console.WriteLine("The computer has chosen to play Lizard")
                Chosen = "L"
            Case 5
                Console.WriteLine("The computer has chosen to play Spock")
                Chosen = "K"
        End Select
        Console.WriteLine()
        Return (Chosen)
    End Function
End Module
