﻿Module Module1

    Sub Main()
        Dim response, player1val, player2val As String
        Dim player1Score As Integer = 0
        Dim player2Score As Integer = 0
        Dim round As Integer = 0
        Dim player1 As Boolean
        While True
            Console.Clear()
            If round Mod 2 = 0 Then
                player1 = True
                Console.WriteLine("PLAYER ONE")
            Else
                player1 = False
                Console.WriteLine("PLAYER TWO")
            End If
            Console.WriteLine()
            Console.WriteLine("Player 1: " & player1Score)
            Console.WriteLine("Player 2: " & player2Score)
            Console.WriteLine("(Q)-Rock")
            Console.WriteLine("(W)-Paper")
            Console.WriteLine("(E)-Scissors")
            Console.WriteLine()
            Console.WriteLine("(P)-Exit")
            Console.WriteLine()
            response = Console.ReadLine()
            Select Case response.ToUpper
                Case "Q"
                    If player1 = True Then
                        player1val = "R"
                    Else
                        player2val = "R"
                    End If
                Case "W"
                    If player1 = True Then
                        player1val = "P"
                    Else
                        player2val = "P"
                    End If
                Case "E"
                    If player1 = True Then
                        player1val = "S"
                    Else
                        player2val = "S"
                    End If
                Case "P"
                    Exit While
                Case Else
                    round = round - 1
            End Select
            If round Mod 2 = 1 Then
                If CheckIfWin(player1val, player2val) = "player1" Then
                    Console.WriteLine("P1 WINS")
                    player1Score = player1Score + 1
                ElseIf CheckIfWin(player1val, player2val) = "player2" Then
                    Console.WriteLine("P2 WINS")
                    player2Score = player2Score + 1
                Else
                    Console.WriteLine("DRAW")
                End If
                Console.ReadKey()
            End If
            round = round + 1

        End While
    End Sub
    Function CheckIfWin(player1, player2)
        Select Case player1
            Case "R"
                Select Case player2
                    Case "P"
                        Return "player2"
                    Case "S"
                        Return "player1"
                End Select
            Case "P"
                Select Case player2
                    Case "R"
                        Return "player1"
                    Case "S"
                        Return "player2"
                End Select
            Case "S"
                Select Case player2
                    Case "R"
                        Return "player2"
                    Case "P"
                        Return "player1"
                End Select
        End Select
        Return "Draw"
    End Function
End Module
